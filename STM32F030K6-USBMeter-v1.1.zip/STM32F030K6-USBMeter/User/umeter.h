/*
 * umeter.h
 *
 *  Created on: 2020��3��15��
 *      Author: Desktop-01
 */

#ifndef UMETER_H_
#define UMETER_H_

#include "main.h"

void MeterInit(void);
void StartSampling(void);
void StopSampling(void);

#endif /* UMETER_H_ */
