/*
 * umeter.c
 *
 *  Created on: 2020��3��15��
 *      Author: Desktop-01
 */

#include "umeter.h"
#include "adc.h"
#include "tim.h"
#include "MonoScreen.h"
#include "stdio.h"
#include "gpio.h"
#include "stdbool.h"

#define ADC_HANDLE                  hadc
#define ADC_SAMP_TIMER_HANDLE       htim3
#define NB_CHANNELS                 6
#define VREFINT_VOLTAGE             1.23F

#define SAMPLING_BUFFER_SIZE        8
#define VBUS_VOLTAGE_CAL_DATA_SIZE  20
#define VBUS_CURRENT_CAL_DATA_SIZE  30

#define VBUS_ADC_VALUE_INDEX        3
#define DP_ADC_VALUE_INDEX          1
#define DM_ADC_VALUE_INDEX          2
#define CUR_ADC_VALUE_INDEX         0
#define VREFEXT_ADC_VALUE_INDEX     4
#define VREFINT_ADC_VALUE_INDEX     5


#define VBUS_DIVIDER_FACTOR         10.0F
#define DM_DIVIDER_FACTOR           1.47F
#define DP_DIVIDER_FACTOR           1.47F
#define CURRENT_DIVIDER_FACTOR      2.0F

#define AUTO_DISPLAY_OFF_TIME       200
#define SETTINGS_SAVED_FLAG         0xEAAE       // ���1KB���ڱ���У׼��Ϣ
#define SETTINGS_PAGE_ADD           0x08007C00

typedef enum{
	STATE_CALIBRATING,
	STATE_INIT,
	STATE_RUNNING,
	STATE_DISPLAY_OFF,
} WorkState;

typedef enum{
	STYLE_1,
	STYLE_2,
} DisplayStyle;

WorkState workState;
DisplayStyle displayStyle;

static uint32_t adcValues[NB_CHANNELS];

float unitVoltage;

uint8_t vbusCurrentSampCount = 0;
uint16_t vbusCurrent;
uint16_t vbusCurrentBuffer[SAMPLING_BUFFER_SIZE + 1];
uint16_t vbusCurrentCalData[VBUS_CURRENT_CAL_DATA_SIZE];

uint8_t voltageVbusSampCount = 0;
uint16_t voltageVbus;
uint16_t voltageVbusBuffer[SAMPLING_BUFFER_SIZE + 1];
uint16_t voltageVbusCalData[VBUS_VOLTAGE_CAL_DATA_SIZE];

uint8_t voltageDMSampCount = 0;
uint16_t voltageDM;
uint16_t voltageDMBuffer[SAMPLING_BUFFER_SIZE + 1];

uint8_t voltageDPSampCount = 0;
uint16_t voltageDP;
uint16_t voltageDPBuffer[SAMPLING_BUFFER_SIZE + 1];

uint16_t power = 0;
uint32_t elapsedTime = 0, startTime = 0;
uint32_t energy = 0, capacity = 0;
uint32_t energyLastRecordTime = 0;

uint8_t countTime = 0;

uint32_t keyPressedTime = 0;

uint32_t noCurrentSampCount = 0;

char strBuffer[32];

static void loadCalibrationData() {
	uint16_t *pData = (uint16_t *) SETTINGS_PAGE_ADD;
	if (*pData++ != SETTINGS_SAVED_FLAG) {
		for (int i = 0; i < VBUS_VOLTAGE_CAL_DATA_SIZE; i++) {
			voltageVbusCalData[i] = 500 + i * 100;
		}
		for (int i = 0; i < VBUS_CURRENT_CAL_DATA_SIZE; i++) {
			vbusCurrentCalData[i] = i * 10;
		}
	}
	else {
		for (int i = 0; i < VBUS_VOLTAGE_CAL_DATA_SIZE; i++) {
			voltageVbusCalData[i] = *pData++;
		}
		for (int i = 0; i < VBUS_CURRENT_CAL_DATA_SIZE; i++) {
			vbusCurrentCalData[i] = *pData++;
		}
	}
}

static void saveCalData() {
	// ���д����
	HAL_FLASH_Unlock();

	FLASH_EraseInitTypeDef sTypeDef;
	sTypeDef.TypeErase = FLASH_TYPEERASE_PAGES;  // ����ҳ
	sTypeDef.PageAddress = SETTINGS_PAGE_ADD;    // ��ַ�趨
	sTypeDef.NbPages = 1;                        // ֻ����1ҳ

	uint32_t pageError = 0;
	HAL_FLASHEx_Erase(&sTypeDef, &pageError);

	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, SETTINGS_PAGE_ADD, SETTINGS_SAVED_FLAG);

	int addOffset = 2;
	for(int i = 0; i < VBUS_VOLTAGE_CAL_DATA_SIZE; i++){
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, addOffset + SETTINGS_PAGE_ADD, voltageVbusCalData[i]);
		FLASH_WaitForLastOperation(0xFFFF);
		addOffset += 2;
	}
	for (int i = 0; i < VBUS_CURRENT_CAL_DATA_SIZE; i++) {
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, addOffset + SETTINGS_PAGE_ADD, vbusCurrentCalData[i]);
		FLASH_WaitForLastOperation(0xFFFF);
		addOffset += 2;
	}

	HAL_FLASH_Lock();
}

static void drawStyle1() {
	MonoScreen_setFontSize(1, 1);
	sprintf(strBuffer, "V+:%d.%02dV", voltageVbus / 100, voltageVbus % 100);
	MonoScreen_DrawString(0, 0, strBuffer);

	sprintf(strBuffer, "D-:%d.%02dV", voltageDM / 100, voltageDM % 100);
	MonoScreen_DrawString(0, 8, strBuffer);

	sprintf(strBuffer, "D+:%d.%02dV", voltageDP / 100, voltageDP % 100);
	MonoScreen_DrawString(0, 16, strBuffer);

	MonoScreen_DrawString(0, 24, "V-:0.00V");

	MonoScreen_setFontSize(2, 2);
	sprintf(strBuffer, "%d.%02dA", vbusCurrent / 100, vbusCurrent % 100);
	MonoScreen_DrawString(63, 0, strBuffer);

	if (power < 10000) {
		sprintf(strBuffer, "%d.%02dW", power / 1000, power % 1000 / 10);
	}
	else {
		sprintf(strBuffer, "%d.%dW", power / 1000, power % 1000 / 100);
	}
	MonoScreen_DrawString(63, 16, strBuffer);
}

static void drawStyle2() {
	MonoScreen_setFontSize(2, 2);
	sprintf(strBuffer, "%02d.%02dV", voltageVbus / 100, voltageVbus % 100);
	MonoScreen_DrawString(0, 0, strBuffer);

	sprintf(strBuffer, "%02d.%02dA", vbusCurrent / 100, vbusCurrent % 100);
	MonoScreen_DrawString(0, 16, strBuffer);

	MonoScreen_setFontSize(1, 1);

	if (power < 10000) {
		sprintf(strBuffer, "%d.%03dW", power / 1000, power % 1000);
	}
	else {
		sprintf(strBuffer, "%d.%02dW", power / 1000, power % 1000 / 10);
	}
	MonoScreen_DrawString(76, 0, strBuffer);

	if (capacity < 10000000) {
		sprintf(strBuffer, "%lu.%03lumAh", capacity / 1000000, capacity % 1000000 / 1000);
	}
	else if (capacity < 100000000) {
		sprintf(strBuffer, "%02lu.%02lumAh", capacity / 1000000, capacity % 1000000 / 10000);
	}
	MonoScreen_DrawString(76, 8, strBuffer);

	if (energy < 10000000) {
		sprintf(strBuffer, "%lu.%03lumWh", energy / 1000000, energy % 1000000 / 1000);
	}
	else if (energy < 100000000) {
		sprintf(strBuffer, "%02lu.%02lumWh", energy / 1000000, energy % 1000000 / 10000);
	}
	MonoScreen_DrawString(76, 16, strBuffer);

	sprintf(strBuffer, "%02lu:%02lu:%02lu",  elapsedTime / 3600000,elapsedTime / 60000 % 60, elapsedTime / 1000 % 60);
	MonoScreen_DrawString(76, 24, strBuffer);
}

static void refreshDisplay(){
	MonoScreen_ClearScreen();

	switch(displayStyle){
	case STYLE_1:
		drawStyle1();
		break;
	default :
		drawStyle2();
	}

	MonoScreen_Flush();
}


static void calcVbusVoltage() {

	float voltage = unitVoltage * adcValues[VBUS_ADC_VALUE_INDEX] * VBUS_DIVIDER_FACTOR;
	uint16_t tempVol = (voltage + 0.005) * 100;

	if (voltageVbusSampCount < SAMPLING_BUFFER_SIZE) {
		voltageVbusBuffer[voltageVbusSampCount++] = tempVol;
		voltageVbus = tempVol;
	}
	else {
		voltageVbusBuffer[SAMPLING_BUFFER_SIZE] = tempVol;
		uint32_t sum = 0;
		for (int i = 0; i < SAMPLING_BUFFER_SIZE; i++) {
			voltageVbusBuffer[i] = voltageVbusBuffer[i + 1];
			sum += voltageVbusBuffer[i];
		}
		voltageVbus = sum / SAMPLING_BUFFER_SIZE;
	}

	if (workState == STATE_CALIBRATING) {
		return;
	}


	float factor = 1.0;
	if (voltageVbus <= voltageVbusCalData[0]) {
		factor = 500.0 / (float) voltageVbusCalData[0];
		voltageVbus = voltageVbus * factor;
		return;
	}

	for (int i = 1; i < VBUS_VOLTAGE_CAL_DATA_SIZE; i++) {
		if (voltageVbus <= voltageVbusCalData[i]) {
			factor = (float) (voltageVbus - voltageVbusCalData[i - 1]) / (float) (voltageVbusCalData[i] - voltageVbusCalData[i - 1]);
			voltageVbus = 500 + factor * 100 + (i-1)*100;
			return;
		}
	}

	factor = (float) (500 + (VBUS_VOLTAGE_CAL_DATA_SIZE - 1) * 100) / (float) voltageVbusCalData[VBUS_VOLTAGE_CAL_DATA_SIZE - 1];
	voltageVbus = voltageVbus * factor;
	return;
}

static void calcDMVoltage(){
	float voltage = unitVoltage * adcValues[DM_ADC_VALUE_INDEX] * DM_DIVIDER_FACTOR;
	uint16_t tempVol = (voltage+0.005) * 100;

	if (voltageDMSampCount < SAMPLING_BUFFER_SIZE) {
		voltageDMBuffer[voltageDMSampCount++] = tempVol;
		voltageDM = tempVol;
	}
	else{
		voltageDMBuffer[SAMPLING_BUFFER_SIZE] = tempVol;
		uint32_t sum = 0;
		for(int i = 0; i < SAMPLING_BUFFER_SIZE; i++){
			voltageDMBuffer[i] = voltageDMBuffer[i + 1];
			sum += voltageDMBuffer[i];
		}
		voltageDM = sum / SAMPLING_BUFFER_SIZE;
	}
}

static void calcDPVoltage(){
	float voltage = unitVoltage * adcValues[DP_ADC_VALUE_INDEX] * DP_DIVIDER_FACTOR;
	uint16_t tempVol = (voltage+0.005) * 100;

	if (voltageDPSampCount < SAMPLING_BUFFER_SIZE) {
		voltageDPBuffer[voltageDPSampCount++] = tempVol;
		voltageDP = tempVol;
	}
	else{
		voltageDPBuffer[SAMPLING_BUFFER_SIZE] = tempVol;
		uint32_t sum = 0;
		for(int i = 0; i < SAMPLING_BUFFER_SIZE; i++){
			voltageDPBuffer[i] = voltageDPBuffer[i + 1];
			sum += voltageDPBuffer[i];
		}
		voltageDP = sum / SAMPLING_BUFFER_SIZE;
	}
}

static void calcVBusCurrent() {
	float current = unitVoltage * adcValues[CUR_ADC_VALUE_INDEX] * CURRENT_DIVIDER_FACTOR;
	uint16_t tempCurrent = (current + 0.005) * 100;

	if (vbusCurrentSampCount < SAMPLING_BUFFER_SIZE) {
		vbusCurrentBuffer[vbusCurrentSampCount++] = tempCurrent;
		vbusCurrent = tempCurrent;
	}
	else {
		vbusCurrentBuffer[SAMPLING_BUFFER_SIZE] = tempCurrent;
		uint32_t sum = 0;
		for (int i = 0; i < SAMPLING_BUFFER_SIZE; i++) {
			vbusCurrentBuffer[i] = vbusCurrentBuffer[i + 1];
			sum += vbusCurrentBuffer[i];
		}
		vbusCurrent = sum / SAMPLING_BUFFER_SIZE;
	}

	if (workState == STATE_CALIBRATING) {
		return;
	}

	if (vbusCurrent <= vbusCurrentCalData[0]) {
		vbusCurrent = 0;
		return;
	}

	float factor = 1.0;
	for (int i = 1; i < VBUS_CURRENT_CAL_DATA_SIZE; i++) {
		if (vbusCurrent <= vbusCurrentCalData[i]) {
			factor = (float) (vbusCurrent - vbusCurrentCalData[i - 1]) / (float) (vbusCurrentCalData[i] - vbusCurrentCalData[i - 1]);
			vbusCurrent = (i-1) * 10 + factor * 10;
			return;
		}
	}

	factor = (float) ((VBUS_CURRENT_CAL_DATA_SIZE-1) * 10) / (float) vbusCurrentCalData[VBUS_CURRENT_CAL_DATA_SIZE-1];
	vbusCurrent = vbusCurrent * factor;
	return;
}

static void calcPower(uint32_t tick){
	power = vbusCurrent * voltageVbus / 10;
	elapsedTime = tick - startTime;
}

static void calcEnergyAndCapacity(uint32_t tick){
	if(energyLastRecordTime != 0){
		uint32_t timeInterval = tick - energyLastRecordTime;
		energy += vbusCurrent * voltageVbus * timeInterval / 36000;
		capacity += vbusCurrent * timeInterval / 360;
	}

	energyLastRecordTime = tick;
}

static void StartSamplingForCal(){
	HAL_TIM_Base_Start(&ADC_SAMP_TIMER_HANDLE);
	HAL_ADC_Start_DMA(&ADC_HANDLE, adcValues, NB_CHANNELS);
}

static bool checkCalOption() {
	GPIO_PinState keyState = HAL_GPIO_ReadPin(KEY_GPIO_Port, KEY_Pin);
	if (keyState) {
		uint8_t i = 50;
		while (i--) {
			HAL_Delay(100);
			keyState = HAL_GPIO_ReadPin(KEY_GPIO_Port, KEY_Pin);
			if (!keyState) {
				return false;
			}
		}
	}
	else {
		return false;
	}

	workState = STATE_CALIBRATING;
	MonoScreen_ClearScreen();
	MonoScreen_DrawString(0, 0, "Release key to start calibration.");
	MonoScreen_Flush();
	while (HAL_GPIO_ReadPin(KEY_GPIO_Port, KEY_Pin));

	StartSamplingForCal();
	HAL_Delay(2000);

	int calVoltage = 0;
	for (int i = 0; i < VBUS_VOLTAGE_CAL_DATA_SIZE; i++) {
		calVoltage = 5 + i;
		while (1) {
			MonoScreen_ClearScreen();
			sprintf(strBuffer, "Cal %d.00V", calVoltage);
			MonoScreen_DrawString(0, 0, strBuffer);

			sprintf(strBuffer, "Now %d.%02dV", voltageVbus / 100, voltageVbus % 100);
			MonoScreen_DrawString(0, 8, strBuffer);

			MonoScreen_Flush();

			if (HAL_GPIO_ReadPin(KEY_GPIO_Port, KEY_Pin)) {
				while (HAL_GPIO_ReadPin(KEY_GPIO_Port, KEY_Pin))
					;
				MonoScreen_DrawString(0, 16, "Accepted!");
				MonoScreen_Flush();
				HAL_Delay(1000);
				voltageVbusCalData[i] = voltageVbus;
				break;
			}
		}
	}

	MonoScreen_ClearScreen();
	MonoScreen_DrawString(0, 0, "Voltage calibration completed! Prepare to calbrate current.");
	MonoScreen_Flush();
	HAL_Delay(2000);

	for (int i = 0; i < VBUS_CURRENT_CAL_DATA_SIZE; i++) {
		while (1) {
			MonoScreen_ClearScreen();
			sprintf(strBuffer, "Cal %d.%d0A", i / 10, i % 10);
			MonoScreen_DrawString(0, 0, strBuffer);

			sprintf(strBuffer, "Now %d.%02dA", vbusCurrent / 100, vbusCurrent % 100);
			MonoScreen_DrawString(0, 8, strBuffer);

			MonoScreen_Flush();

			if (HAL_GPIO_ReadPin(KEY_GPIO_Port, KEY_Pin)) {
				while (HAL_GPIO_ReadPin(KEY_GPIO_Port, KEY_Pin));
				MonoScreen_DrawString(0, 16, "Accepted!");
				MonoScreen_Flush();
				HAL_Delay(1000);
				vbusCurrentCalData[i] = vbusCurrent;
				break;
			}
		}
	}

	MonoScreen_ClearScreen();
	MonoScreen_DrawString(0, 0, "Completed.");
	MonoScreen_Flush();

	StopSampling();
	saveCalData();
	HAL_Delay(1000);

	return true;
}

static void keyClicked() {
	if (workState == STATE_DISPLAY_OFF) {
		noCurrentSampCount = 0;
		workState = STATE_RUNNING;
		return;
	}

	if (displayStyle == STYLE_1) {
		displayStyle = STYLE_2;
	}
	else {
		displayStyle = STYLE_1;
	}
}

void MeterInit(){
	HAL_NVIC_DisableIRQ(KEY_EXTI_IRQn);

	workState = STATE_INIT;
	displayStyle = STYLE_1;
	bool cal = checkCalOption();
	if(!cal){
		loadCalibrationData();
	}
	HAL_NVIC_EnableIRQ(KEY_EXTI_IRQn);
}

void StartSampling(){
	HAL_TIM_Base_Start(&ADC_SAMP_TIMER_HANDLE);
	HAL_ADC_Start_DMA(&ADC_HANDLE, adcValues, NB_CHANNELS);
	workState = STATE_RUNNING;
	startTime = HAL_GetTick();
}

void StopSampling(){
	HAL_ADC_Stop_DMA(&ADC_HANDLE);
	HAL_TIM_Base_Stop(&ADC_SAMP_TIMER_HANDLE);
	workState = STATE_INIT;
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadcsrc){
	uint32_t unitVoltageValue = adcValues[5];
	unitVoltage = VREFINT_VOLTAGE / unitVoltageValue;

	uint32_t tick = HAL_GetTick();

	calcVbusVoltage();
	calcDMVoltage();
	calcDPVoltage();
	calcVBusCurrent();
	calcPower(tick);
	if(countTime == 0){
		calcEnergyAndCapacity(tick);
	}

	countTime++;
	if(countTime > 10){
		countTime = 0;
	}

	if(vbusCurrent != 0){
		noCurrentSampCount = 0;
		if(workState == STATE_DISPLAY_OFF){
			workState = STATE_RUNNING;
		}
	}
	else if(++ noCurrentSampCount > AUTO_DISPLAY_OFF_TIME && workState == STATE_RUNNING){
		workState = STATE_DISPLAY_OFF;
		MonoScreen_ClearScreen();
		MonoScreen_Flush();
	}

	if(workState == STATE_RUNNING){
		refreshDisplay();
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	if(HAL_GPIO_ReadPin(KEY_GPIO_Port, KEY_Pin)){
		keyPressedTime = HAL_GetTick();
	}
	else{
		uint32_t passed = HAL_GetTick() - keyPressedTime;
		if(passed > 70){
			keyClicked();
		}
	}
}
